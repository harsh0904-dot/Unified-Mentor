
# 📈 TCS Stock Data – Live and Latest

*A Comprehensive Stock Analysis and Forecasting Project Using Machine Learning & Deep Learning*  
**Author:** Harsh Vardhan Singh | MSc Data Science | Chanakya University

---

## 🗂️ Table of Contents

- [📌 Project Overview](#-project-overview)
- [🧠 Objectives](#-objectives)
- [📊 Dataset Description](#-dataset-description)
- [🔎 Exploratory Data Analysis](#-exploratory-data-analysis)
- [🧮 Modeling Approaches](#-modeling-approaches)
- [📉 Model Evaluation](#-model-evaluation)
- [🛠️ Streamlit Dashboard](#-streamlit-dashboard)
- [📌 Key Insights](#-key-insights)
- [🚀 Future Scope](#-future-scope)
- [🧰 Tech Stack & Requirements](#-tech-stack--requirements)
- [🧑‍💻 Author](#-author)
- [📄 License](#-license)

---

## 📌 Project Overview

This project focuses on analyzing and forecasting the stock prices of **Tata Consultancy Services (TCS)**, one of the largest IT service providers globally. Using historical stock data from 2002 to 2023, the project blends statistical techniques, ML algorithms, and deep learning models to derive actionable financial insights and build robust predictive models.

A **Streamlit dashboard** has been built to visualize stock trends, corporate actions, and run predictive analytics interactively.

---

## 🧠 Objectives

- Analyze TCS stock price trends, volatility, and volume behavior
- Engineer features to enhance predictive power
- Apply linear regression and LSTM models for forecasting
- Identify trade signals using moving average crossovers
- Deploy insights using a dynamic Streamlit dashboard

---

## 📊 Dataset Description

The dataset comprises **4,463 daily records** covering TCS stock data from 2002 to 2023.

**Key Columns:**
- `Date`: Trading date
- `Open, High, Low, Close`: Daily price movement
- `Volume`: Investor activity
- `Dividends` & `Stock Splits`: Corporate actions

**Preprocessing Steps:**
- Converted `Date` to datetime format
- Sorted chronologically
- Applied forward fill for missing values
- Created moving averages and lag features

---

## 🔎 Exploratory Data Analysis

**Insights Uncovered:**
- Long-term bullish trend with short-term corrections
- Close price is highly correlated with Open, High, and Low (>99%)
- Volume spikes align with dividend/split announcements
- Visualizations: Heatmaps, line plots, and moving averages

---

## 🧮 Modeling Approaches

### 🔹 Linear Regression (Baseline)
- Features: Open, High, Low, Volume, Prev_Close, Date Parts
- Evaluation: R² Score, MSE
- Outcome: Captures linear patterns but not temporal sequences

### 🔹 LSTM (Advanced)
- Inputs: Normalized closing price sequences
- Architecture: 1 LSTM Layer (50 units) + Dense
- Outcome: Learns historical dependencies and handles volatility

---

## 📉 Model Evaluation

**Evaluation Metrics:**
- Linear Regression: Moderate R², High MSE
- LSTM:  
  - Mean Absolute Error (MAE): ~69.52  
  - Visual accuracy on actual vs predicted price curves

LSTM outperformed linear models in sequence-based predictions and captured stock market behavior effectively.

---

## 🛠️ Streamlit Dashboard

An interactive web application for analysts and investors.

### 📂 Key Features:
- Upload your own TCS CSV data or use the default
- Apply date filters to focus on specific time windows
- Visualize:
  - Price trends with 30/50/200-day moving averages
  - Volume, Dividends, and Stock Splits
  - Close price predictions using Linear Regression

### ▶️ To Launch the App:

```bash
pip install -r requirements.txt
streamlit run tcs_dashboard.py
````

---

## 📌 Key Insights

* TCS stock behavior is **predictable using engineered features**
* Lag features & moving averages enhanced model performance
* Volume & corporate actions showed **delayed or minimal impact**
* Moving average crossovers act as strong **trading signal generators**
* LSTM models generalize well across different market regimes

---

## 🚀 Future Scope

* 🔄 Integrate live TCS data via APIs (e.g., Yahoo Finance, Alpha Vantage)
* 📈 Add ARIMA & Prophet models for long-term forecasting
* 🌐 Deploy dashboard via Streamlit Cloud or AWS
* 🔍 Incorporate SHAP/LIME for model explainability
* 🧮 Add indicators like RSI, MACD, Bollinger Bands for quant-based strategies

---

## 🧰 Tech Stack & Requirements

**Languages & Tools:**

* Python, Jupyter Notebook, Streamlit
* Pandas, NumPy, Scikit-learn, Matplotlib, Seaborn
* TensorFlow/Keras (optional for LSTM)

**To install all dependencies:**

```bash
pip install -r requirements.txt
```

---

## 👨‍💻 Author

**Harsh Vardhan Singh**
MSc Data Science | Chanakya University
📧 [singhharshvardhan178@gmail.com](mailto:harshvardhansingh@example.com)
📍 India

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
Feel free to fork, use, or contribute to this project.

---


