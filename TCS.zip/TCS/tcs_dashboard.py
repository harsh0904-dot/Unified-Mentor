# tcs_dashboard.py

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error

# Page Config
st.set_page_config(page_title="TCS Stock Dashboard", layout="wide")

# Title
st.title("📈 TCS Stock Data - Live & Historical Dashboard")

# Sidebar: Upload CSV or use default
st.sidebar.header("📂 Upload Data")
uploaded_file = st.sidebar.file_uploader("Upload your CSV file", type=["csv"])

@st.cache_data
def load_data(file):
    df = pd.read_csv(file)
    df['Date'] = pd.to_datetime(df['Date'])
    df.sort_values('Date', inplace=True)
    df['MA30'] = df['Close'].rolling(window=30).mean()
    df['MA50'] = df['Close'].rolling(window=50).mean()
    df['MA200'] = df['Close'].rolling(window=200).mean()
    return df

if uploaded_file:
    df = load_data(uploaded_file)
else:
    df = load_data("TCS_stock_history.csv")  # Ensure this CSV is in the same folder

# Sidebar: Date filter
st.sidebar.subheader("📅 Date Range Filter")
min_date, max_date = df['Date'].min(), df['Date'].max()
start_date = st.sidebar.date_input("Start Date", min_value=min_date, max_value=max_date, value=min_date)
end_date = st.sidebar.date_input("End Date", min_value=min_date, max_value=max_date, value=max_date)

# Filter data by selected date range
filtered_df = df[(df['Date'] >= pd.to_datetime(start_date)) & (df['Date'] <= pd.to_datetime(end_date))]

# Tabs
tab1, tab2, tab3 = st.tabs(["📊 Stock Trends", "📉 Volume & Splits", "🤖 Predict Close Price"])

# === TAB 1 ===
with tab1:
    st.subheader("📊 TCS Close Price & Moving Averages")
    st.line_chart(filtered_df.set_index('Date')[['Close', 'MA30', 'MA50', 'MA200']])

# === TAB 2 ===
with tab2:
    st.subheader("📉 Volume, Dividends & Stock Splits")
    
    st.area_chart(filtered_df.set_index('Date')[['Volume']])
    col1, col2 = st.columns(2)
    with col1:
        st.bar_chart(filtered_df.set_index('Date')[['Dividends']])
    with col2:
        st.bar_chart(filtered_df.set_index('Date')[['Stock Splits']])

# === TAB 3 ===
with tab3:
    st.subheader("🤖 Linear Regression: Close Price Prediction")

    temp_df = filtered_df.copy()
    temp_df['Prev_Close'] = temp_df['Close'].shift(1)
    temp_df.dropna(inplace=True)

    features = ['Open', 'High', 'Low', 'Volume', 'Prev_Close']
    X = temp_df[features]
    y = temp_df['Close']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    r2 = r2_score(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)

    st.write("📌 **Model Evaluation**")
    st.metric("R² Score", f"{r2:.4f}")
    st.metric("MSE", f"{mse:.2f}")

    result_df = pd.DataFrame({"Actual": y_test, "Predicted": y_pred})
    st.line_chart(result_df.reset_index(drop=True))
