
# 🩸 Personalized Healthcare Recommendation System using Machine Learning

> A real-time, intelligent application for predicting patient risk profiles and providing actionable health recommendations — powered by a Random Forest model, presented through an interactive Streamlit web interface.

---

## 📘 Project Description

In today's data-rich healthcare environment, personalized recommendations play a crucial role in improving patient outcomes. This project leverages **machine learning** to analyze individual health data and generate **custom healthcare suggestions**—such as recommending medical check-ups, lifestyle changes, or identifying low-risk profiles.

The system predicts whether a patient is likely to be at risk based on blood donation behavior and suggests preventive or corrective actions accordingly.

---

## 🎯 Objectives

- Predict **likelihood of blood donation** based on patient history.
- Deliver **custom recommendations**: low, moderate, or high risk.
- Provide an **interactive and intuitive frontend** for both patients and healthcare professionals.
- Enable **early detection of health issues** via clinical indicators.

---

## 🧠 Problem Understanding

In this project, we aim to:
- Analyze patient data related to **blood donation frequency, recency, volume**, and **duration**.
- Train a machine learning model to **classify patients** as potential donors or not.
- Use the prediction **probability** to drive healthcare advice.
- Deploy a Streamlit interface for real-time, user-friendly input/output.

---

## 🗃️ Dataset Information

The model is trained on a blood donation dataset, containing:

| Feature          | Description                                  |
|------------------|----------------------------------------------|
| `Recency`        | Months since the last donation               |
| `Frequency`      | Number of total donations                    |
| `Monetary`       | Total volume of blood donated (in c.c.)      |
| `Time`           | Months since the first donation              |

**Data Link** 🔗: [Click to Download Dataset](https://drive.google.com/file/d/188llssNtR9agfbUlvTzWoByPeN4zMNMB/view?usp=sharing)

---

## 🛠️ Technologies & Tools

| Category         | Tools Used                                   |
|------------------|----------------------------------------------|
| Language         | Python 3.x                                    |
| IDE              | Jupyter Notebook, VS Code                     |
| Machine Learning | Scikit-learn (Random Forest Classifier)       |
| Web App          | Streamlit                                     |
| Deployment       | Localhost (Streamlit)                         |
| Serialization    | Joblib (for model and scaler)                 |
| Data Processing  | Pandas, NumPy                                 |
| Visualization    | Seaborn, Matplotlib (in notebook)             |

---

## 🔬 Data Science Workflow

### 1. 📥 Data Collection
- Data is collected from a structured blood donation dataset.
- Each row represents an individual’s donation history.

### 2. 📊 Data Preprocessing
- Features scaled using `StandardScaler`.
- A derived feature `Donation_Per_Month = Frequency / (Time + 1)` was created.
- Data split into training and test sets.

### 3. 🧠 Model Training
- Model: **Random Forest Classifier**
- Why Random Forest?
  - Handles non-linearity
  - Robust to outliers
  - Provides feature importance
- Trained using scikit-learn pipeline for ease of scaling and reproducibility.

### 4. 📈 Evaluation Metrics
- `Accuracy`
- `Precision`, `Recall`, `F1-score`
- `ROC-AUC`
- Visual tools: Confusion matrix, ROC curve

### 5. 💬 Interpretation
Prediction is binary (Likely to Donate = Yes/No) with a **probability score**. Based on the score:

| Probability Range | Recommendation                                  |
|-------------------|--------------------------------------------------|
| `>= 80%`          | 🔴 High Risk – Immediate consultation advised    |
| `50-79%`          | 🟠 Moderate Risk – Improve lifestyle & check-up |
| `< 50%`           | 🟢 Low Risk – No action required                 |

---

## 🌐 Application Interface (Streamlit)

### Features:
- Sliders for entering patient data.
- Real-time prediction on button click.
- Interpretable recommendation based on probability.

### UI Components:
- `Recency`, `Frequency`, `Monetary`, `Time` as input sliders
- Real-time model prediction using `.predict()` and `.predict_proba()`
- Recommendation badges:
  - `st.success()` for Low Risk
  - `st.warning()` for Moderate Risk
  - `st.error()` for High Risk

### Run the App:
```bash
streamlit run app.py
````

---

## 🎥 Sample Use Case

```text
Patient: Male, 52 years old
Recency: 4 months
Frequency: 12 donations
Monetary: 3000 ml
Time: 72 months

🧠 Prediction: "Yes, likely to donate" (85% confidence)
🩺 Recommendation: High Risk — Consult a physician and take preventive action
```

---

## 📂 Project Structure

```
📁 personalized-healthcare-app/
│
├── app.py                  # Streamlit app
├── healthcare.ipynb        # Model training, EDA, and evaluation
├── rf_model.pkl            # Trained ML model
├── scaler.pkl              # Standard scaler for inputs
├── requirements.txt        # Required Python libraries
├── README.md               # This file
└── assets/                 # Screenshots, presentation, dataset
```

---

## 📊 PPT Summary Highlights

* **Model Justification:** Random Forest chosen for its accuracy and interpretability.
* **Performance Snapshot:** Strong F1-score and ROC-AUC.
* **Strategy Recommendations:**

  * Integrate into hospital systems (EHR)
  * Pilot testing with feedback loop
  * Potential for mobile health (mHealth) app

> *Refer to `Personalized_Healthcare_PPT.pptx` for detailed business and technical insights.*

---

## ✅ Future Enhancements

* Add support for **clinical indicators** (BP, cholesterol, glucose, etc.).
* Build an **end-to-end API** with Flask or FastAPI.
* Integrate **explainable AI (SHAP/LIME)** for transparency.
* Deploy on cloud: Heroku / AWS / Azure.
* Expand dataset for better generalization.

---

## 👨‍⚕️ Author & Credits

**👤 Harsh Vardhan Singh**
🎓 MSc in Data Science |
📁 This project was created as part of an **ML/FA/DA Capstone Project**

📖 Reference:
Inspired by [CodeClause Personalized Healthcare ML Project](https://github.com/dhrupad17/CodeClause_Personalized_Medicine_Recommending_System)

---


