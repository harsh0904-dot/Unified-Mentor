# Streamlit App for Personalized Healthcare Recommendations

import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Load trained model and scaler
model = joblib.load("rf_model.pkl")
scaler = joblib.load("scaler.pkl")

# App title
st.title("🩸 Personalized Healthcare Recommendation System")
st.markdown("Enter patient data below to receive prediction and advice.")

# Input fields
recency = st.slider("Recency (months since last donation)", 0, 74, 2)
frequency = st.slider("Frequency (total donations)", 1, 50, 5)
monetary = st.slider("Monetary (total blood donated)", 250, 12500, 1000, step=250)
time = st.slider("Time (months since first donation)", 2, 99, 30)

# Prepare input
input_data = pd.DataFrame([[recency, frequency, monetary, time]], 
                          columns=["Recency", "Frequency", "Monetary", "Time"])

# Scale features
input_scaled = scaler.transform(input_data)

# Add derived feature
donation_per_month = frequency / (time + 1)
input_final = pd.DataFrame(input_scaled, columns=["Recency", "Frequency", "Monetary", "Time"])
input_final["Donation_Per_Month"] = donation_per_month

# Predict
if st.button("Get Recommendation"):
    prob = model.predict_proba(input_final)[0][1]
    prediction = model.predict(input_final)[0]

    st.subheader(f" Likely to Donate? {'Yes' if prediction == 1 else 'No'} ({prob*100:.2f}%)")

    # Recommendation logic
    if prob >= 0.80:
        st.error(" High Risk — Immediate lifestyle changes & consult a physician.")
    elif prob >= 0.50:
        st.warning(" Moderate Risk — Regular check-up & lifestyle improvements.")
    else:
        st.success(" Low Risk — No action required. Keep maintaining your health.")
