
# 🛒 Supermart Grocery Sales – Retail Analytics

## 📌 Project Summary

**Supermart Grocery Sales – Retail Analytics** is a complete data analytics and machine learning project designed to simulate real-world retail analysis. It leverages a fictional dataset that mimics grocery order data from Tamil Nadu, India, and applies **advanced exploratory data analysis (EDA)** and **predictive modeling** to derive business insights and sales forecasts.

This repository contains:
- A **data-driven business analysis notebook** with end-to-end implementation
- A **presentation deck** for communicating insights to stakeholders
- **Machine learning models** to predict sales based on business variables

---

## 🎯 Business Objective

Retailers constantly seek to optimize their operations, product offerings, and supply chain based on **consumer behavior and sales trends**. In this project, we aim to:

- Identify **top-performing product categories and cities**
- Understand **seasonal and yearly sales patterns**
- Predict future sales using machine learning
- Provide **strategic recommendations** for improving business performance

This project simulates how a **data analyst at a retail company** would analyze sales data, generate insights, and communicate results to business leaders.

---

## 📊 Dataset Description

The dataset used in this project is a fictional retail dataset intended for analytical practice. It includes around 10,000 grocery orders placed across Tamil Nadu.

### Key Features:

| Column | Description |
|--------|-------------|
| `Order ID` | Unique identifier for each order |
| `Customer Name` | Name of the customer |
| `Category` | Main product category (e.g., Food Grains, Beverages) |
| `Sub Category` | More detailed product type (e.g., Health Drinks) |
| `City` | Customer’s city |
| `State` | All records are from Tamil Nadu |
| `Region` | Region of Tamil Nadu (North, South, etc.) |
| `Order Date` | Date the order was placed |
| `Sales` | Revenue earned on the order |
| `Discount` | Discount applied to the order |
| `Profit` | Net profit from the order |

**Additional engineered features**:
- `Month`, `Year`, `Month_no`: Derived from `Order Date` for temporal analysis

---

## 🧰 Tools & Technologies Used

- **Python**: Data wrangling, visualization, and modeling
- **Pandas, NumPy**: Data processing
- **Seaborn, Matplotlib**: Data visualization
- **Scikit-learn**: Machine learning
- **Jupyter Notebook**: Code and narrative integration
- **PowerPoint**: Business presentation and storytelling

---

## 📈 Data Analysis & Visualization Highlights

### 🧪 Exploratory Data Analysis (EDA)
Performed in-depth analysis on:

- **Sales by Category**: Identified which categories drive the most revenue
- **City-level Sales**: Discovered top-performing cities for strategic focus
- **Monthly & Yearly Trends**: Visualized seasonality and yearly sales growth
- **Correlation Heatmap**: Analyzed relationships between discount, profit, and sales

### 📍 Key Visualizations
- 📊 Bar chart of category-wise sales
- 📈 Line chart showing monthly sales trend
- 🧭 Pie chart of yearly sales contributions
- 🏙️ City-level sales ranking
- 🔥 Correlation heatmap for sales drivers

---

## 🧠 Machine Learning Model – Sales Prediction

### Objective:
Predict future `Sales` based on product, region, and discount information.

### Workflow:
1. **Data Preprocessing**:
   - Categorical encoding
   - Feature engineering (`month`, `year`)
   - Missing value handling

2. **Modeling**:
   - Used **Linear Regression** to build a baseline prediction model
   - Features used: `Category`, `Sub Category`, `City`, `Region`, `Discount`, `Profit`, etc.

3. **Evaluation**:
   - **R² Score**: `0.82` → Strong predictive power
   - **MSE**: ~`1758.26` → Low error indicating model accuracy

4. **Visualization**:
   - Scatter plot of Actual vs Predicted Sales

> ✅ Future upgrades may involve using models like **Random Forest** or **XGBoost** for greater accuracy.

---

## 💡 Business Insights & Recommendations

### 📌 Top Insights:
- **Egg, Meat & Fish** and **Beverages** are high-performing categories.
- **Chennai, Coimbatore, Madurai, Erode, Salem** are the top 5 cities for sales.
- Sales increase significantly in **November–December**, indicating a strong **festive season effect**.
- High discounts correlate negatively with profits but can stimulate higher volume sales.

### 💼 Strategic Recommendations:
1. **Focus on Top Cities**:
   - Strengthen logistics and inventory in top 5 cities
   - Launch local promotions tailored to these zones

2. **Category Investment**:
   - Prioritize stock and marketing for high-sales categories
   - Introduce combo deals during high-demand months

3. **Seasonal Campaigns**:
   - Implement targeted advertising during the year-end to capture peak sales season

---

## 📊 Presentation for Stakeholders

A **PowerPoint business presentation** has been created to summarize key findings, ML insights, and strategic actions. It’s designed for use in:
- Stakeholder meetings
- Client presentations
- Job interviews to showcase analytics communication skills

🗂️ File: `Supermart_Grocery_Analytics_Presentation.pptx`

---

## 📁 Repository Structure

```bash
supermart-grocery-retail-analytics/
│
├── Supermart.ipynb                        # Jupyter Notebook with EDA & ML
├── Supermart_Grocery_Analytics_Presentation.pptx  # Executive-level presentation
├── README.md                              # Project documentation
└── data/
    └── Supermart Grocery Sales - Retail Analytics Dataset.csv
````

---

## 🚀 How to Run the Project

1. **Clone the repo**:

   ```bash
   git clone https://github.com/<your-username>/supermart-grocery-retail-analytics.git
   cd supermart-grocery-retail-analytics
   ```

2. **Install dependencies**:

   ```bash
   pip install pandas numpy matplotlib seaborn scikit-learn
   ```

3. **Run the Jupyter Notebook**:
   Open `Supermart.ipynb` using Jupyter Notebook or VS Code.

4. **Download Dataset** (if not included):
   [Download from Google Drive](https://drive.google.com/file/d/1Vx-Ibn11HKofkJasjMZFyigemSu7TOeB/view?usp=sharing)

---

## 📈 Future Enhancements

* Use advanced models like **Random Forest, XGBoost, or LightGBM**
* Build an interactive **dashboard (e.g., Plotly Dash or Streamlit)**
* Integrate **real-time sales prediction** using APIs
* Perform **geospatial sales clustering** for location-based strategies

---

## 👨‍💼 About the Analyst

**Harsh Vardhan Singh**
📌 MSc in Data Science | 🎯 Passionate about Data, Business Analytics & Forecasting


---

## 📜 Acknowledgments

* Dataset by: [sushantag9 on Kaggle](https://www.kaggle.com/datasets/sushantag9/supermart-grocery-sales-retail-analytics-dataset)
* Project inspiration: Retail sales use cases from real-world FMCG domains

---

