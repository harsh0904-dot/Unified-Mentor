
# 🧑‍💼 IBM HR Analytics – Employee Attrition & Performance

## 📌 Executive Summary

This project addresses a key challenge faced by modern enterprises: **employee attrition**. High turnover not only incurs significant financial costs but also disrupts continuity, hinders team performance, and threatens institutional knowledge. Through data-driven insights, we examine patterns of attrition and propose actionable strategies to boost **employee retention** and enhance **organizational performance**.

This analysis uses a **realistic HR simulation dataset** published by IBM to:
- Explore attrition trends across demographics and job metrics
- Identify top drivers of turnover
- Present strategic recommendations grounded in evidence
- Estimate the **ROI impact of retention improvements**

---

## 🎯 Project Goals

| Objective | Description |
|-----------|-------------|
| 🔍 Analyze Attrition Patterns | Understand who is leaving and why |
| 📊 Discover Key Influencers | Overtime, job satisfaction, compensation, etc. |
| 💰 Quantify Business Impact | Estimate cost implications of turnover |
| 🧠 Recommend HR Strategies | Provide actionable, data-backed solutions |
| 📈 Enable Predictive Analysis | Lay the foundation for risk scoring and modeling |

---

## 🗃️ Dataset Overview

The dataset simulates employee data from an enterprise-level HR system and contains **1,470 records and 35 features**. It covers personal demographics, job role metrics, performance scores, compensation details, and attrition labels.

| Feature Category     | Key Attributes Included |
|----------------------|-------------------------|
| 📌 Personal Info     | Age, Gender, Marital Status, Education |
| 🏢 Job Details       | Department, Job Role, Years at Company |
| 💼 Performance       | Performance Rating, Promotions |
| 💰 Compensation      | Monthly Income, Stock Option Level |
| 💬 Satisfaction      | Job Satisfaction, Work-Life Balance |
| ⏱️ Work Patterns     | Business Travel, Overtime, Hours Worked |
| 🎯 Target Variable   | `Attrition` (Yes/No) |

📂 **Data Quality**: No missing or duplicated values. All features are appropriately typed and encoded.

🔗 [Download Dataset (Google Drive)](https://drive.google.com/file/d/1tv2dfgghMKzN_mKmdn0ymCUrkwVvBk3w/view?usp=sharing)

---

## 🧪 Analytical Methodology

### 🔹 1. Data Preprocessing
- Verified column types and converted categorical fields
- Checked for null values and duplicate rows (none found)
- Standardized column formats for ease of analysis

### 🔹 2. Exploratory Data Analysis (EDA)
- Distribution of attrition by **gender, department, age, income**
- Aggregated attrition rates by **Job Role, Work-Life Balance, OverTime**
- Cross-analysis of attrition vs **Job Involvement**, **Satisfaction Scores**

### 🔹 3. Attrition Rate Calculation
- Total Attrition: **16.1%** (≈1 in every 6 employees)
- Key insights:
  - Overtime employees are **2–3x more likely** to leave
  - Attrition higher in **frequent travelers** and **low-income segments**
  - **Low Job Involvement** and **Work-Life Balance** are strong drivers

### 🔹 4. Business Impact Estimation
- Average employee replacement cost = **$12,000**
- Annual projected attrition cost = **$1.2M+**
- Financial justification for investing in retention strategies

---

## 📈 Key Visual Insights

| Visualization | Description |
|---------------|-------------|
| 📊 Attrition Distribution | Proportion of “Yes” vs “No” attrition |
| 🧑‍💼 Age vs Attrition KDE Plot | Younger employees show slightly higher turnover |
| 📍 Department-Level Comparison | Sales & R&D have higher attrition hotspots |
| 📉 Monthly Income vs Attrition | Lower income levels correlate with high attrition |
| 🧱 Job Satisfaction, Environment, Work-Life Balance | Lower satisfaction significantly increases attrition |

---

## 💡 Strategic Recommendations

| Focus Area | Recommended Action | Business Rationale |
|------------|---------------------|---------------------|
| 🕓 Work Hours | Implement flexible schedules & reduce overtime | Reduces burnout and enhances retention |
| 🎓 Career Path | Create clear internal mobility and promotion tracks | Improves engagement and loyalty |
| 🤝 Recognition | Introduce employee appreciation programs | Boosts job involvement and morale |
| 🎯 Risk Modeling | Build predictive models for high attrition risk profiles | Enables early intervention and HR planning |
| 📊 Dashboards | Automate HR dashboards for ongoing monitoring | Provides leadership with real-time insights |

---

## 💰 ROI Opportunity

- **Current Cost of Attrition**: Estimated at **$1.2M per annum**
- **Targeted Retention** of high-risk roles and departments could cut this by 30–50%
- Justifying strategic investments in:
  - People analytics
  - Compensation benchmarking
  - Employee wellness & culture programs

---

## 🧰 Tools Used

| Category | Tools / Libraries |
|----------|--------------------|
| Programming | Python |
| Data Handling | Pandas, NumPy |
| Visualization | Matplotlib, Seaborn |
| Presentation | PowerPoint |
| Platform | Jupyter Notebook / VS Code |

---

## 📂 Repository Structure

```bash
ibm-hr-attrition-analysis/
│
├── IBM.ipynb                            # Full analysis in Python
├── IBM_HR_Attrition_Executive_Presentation.pptx  # Business summary deck
├── IBM HR Analytics Employee Attrition.pdf       # Project reference brief
├── README.md                           # Project documentation (this file)
└── data/
    └── WA_Fn-UseC_-HR-Employee-Attrition.csv     # Raw dataset (external)
````

---

## 🚀 How to Run This Project

1. **Clone the Repository**:

   ```bash
   git clone https://github.com/<your-username>/ibm-hr-attrition-analysis.git
   cd ibm-hr-attrition-analysis
   ```

2. **Install Required Libraries**:

   ```bash
   pip install pandas matplotlib seaborn numpy
   ```

3. **Launch Notebook**:

   * Open `IBM.ipynb` in Jupyter or VS Code
   * Run cells sequentially to reproduce analysis and visuals

4. **Download Dataset** (if not included):
   [Download Here](https://drive.google.com/file/d/1tv2dfgghMKzN_mKmdn0ymCUrkwVvBk3w/view?usp=sharing)

---

## 🧠 Next Steps

* 🔮 Build a predictive attrition classification model using Logistic Regression or Random Forest
* 📊 Deploy a real-time attrition dashboard using Streamlit or Power BI
* 📝 Incorporate qualitative survey data (exit interviews, engagement scores)
* 🧪 Test hypothesis-driven interventions (A/B testing in HR policy)

---

## 👤 About the Analyst

**Harsh Vardhan Singh**
📍 MSc in Data Science | 
🛠️ Tools: Python, SQL, Excel, Dashboards


---

## 🏷️ References

* Dataset Source: IBM (via Kaggle)
* GitHub Inspiration: [Niranjankumar-c/HRAnalyticsEmployeeAttrition](https://github.com/Niranjankumar-c/HRAnalyticsEmployeeAttrition)
* Business Insight Framework: McKinsey’s 7-S HR Alignment Model

---


```
